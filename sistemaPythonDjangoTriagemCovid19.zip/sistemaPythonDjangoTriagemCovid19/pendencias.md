# Pendências no sistema

- corrigir data e hora da triagem no __str__
- listagem de triagens e consultas customizadas ao usuario logado
- listagem de triagens, corrigir o responsável pela triagem

- inserir datepick em datas

- revisar as permissões