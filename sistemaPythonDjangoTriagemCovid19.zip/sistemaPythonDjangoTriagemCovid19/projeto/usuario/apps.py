from django.apps import AppConfig


class UsuarioConfig(AppConfig):
    name = 'usuario'
