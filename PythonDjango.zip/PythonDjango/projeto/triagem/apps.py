from django.apps import AppConfig


class TriagemConfig(AppConfig):
    name = 'triagem'
