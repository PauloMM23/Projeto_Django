from django.apps import AppConfig


class ConsultaConfig(AppConfig):
    name = 'consulta'
