from django.apps import AppConfig


class UnidadeConfig(AppConfig):
    name = 'unidade'
